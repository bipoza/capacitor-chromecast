package com.gameleap.capacitor_chromecast.lib;

public class ChromecastException extends Exception {
}
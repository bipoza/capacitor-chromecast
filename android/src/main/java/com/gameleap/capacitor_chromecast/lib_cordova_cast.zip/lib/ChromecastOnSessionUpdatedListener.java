package com.gameleap.capacitor_chromecast.lib;

import org.json.JSONObject;

public interface ChromecastOnSessionUpdatedListener {
	void onSessionUpdated(boolean isAlive, JSONObject properties);
	void onMessage(ChromecastSession session, String namespace, JSONObject message);
}
